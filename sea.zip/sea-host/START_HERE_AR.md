# Sea Host — ابدأ من هنا

هذه النسخة تحتوي على لوحة Sea Host، قاعدة بيانات SQLite، دخول المالك فقط، رمز تحقق بالبريد الإلكتروني، وإدارة مشاريع Python عبر عامل Docker منفصل.

## قبل التشغيل
- تحتاج خادم Linux مناسبًا، وDocker Engine مع Docker Compose.
- انسخ `.env.example` إلى `.env`، ثم أنشئ قيمًا عشوائية منفصلة لـ `APP_SECRET_KEY` و`RUNNER_TOKEN` (كل واحدة 32 بايت على الأقل).
- اضبط `HOSTPANEL_DATA_DIR` إلى مسار دائم مطلق على الخادم، مثل `/srv/seahost-data`.
- اضبط `OWNER_EMAIL` على بريد المالك الذي ستستخدمه لتسجيل الدخول.
- لإرسال الرمز، اضبط SMTP. مع Gmail استخدم App Password مخصصًا بعد تفعيل التحقق بخطوتين، لا كلمة مرور حساب Google العادية.
- في الإنتاج خلف HTTPS، اترك `COOKIE_SECURE=1`.

## إنشاء الحساب وتشغيل الخدمات
بعد تجهيز `.env` ومسار البيانات حسب `DEPLOY_HOME_AR.md`:

```bash
sudo docker compose config --quiet
sudo docker compose build
sudo docker compose run --rm --no-deps panel python create_owner.py
sudo docker compose up -d
sudo docker compose ps
curl -fsS http://127.0.0.1:8000/api/health
sudo docker compose logs --tail=80 panel runner
```

سيطلب `create_owner.py` كلمة مرور المالك بشكل تفاعلي. لا توجد كلمة مرور افتراضية، ولا يوجد تسجيل عام. يحتاج تسجيل الدخول إلى كلمة المرور ثم رمز OTP المرسل إلى البريد.

## ملاحظات أمان مهمة
- لا ترفع `.env` ولا ترسل أسرار SMTP أو مفاتيح التشغيل لأي شخص.
- لا تنشر المنفذ `8091` الخاص بعامل Docker على الإنترنت، ولا تفتح Docker socket للإنترنت.
- لوحة الويب مربوطة افتراضيًا على `127.0.0.1:8000`؛ استخدم HTTPS عبر reverse proxy مثل Caddy وفق الدليل.
- تشغيل الملفات الحقيقية يتطلب Docker daemon عاملًا على الخادم. الاختبارات الآلية لا تستبدل اختبار التشغيل على خادمك.
- شبكة مشاريع Python افتراضيًا `none` لعزلها؛ تثبيت الاعتماديات التي تحتاج الإنترنت أو تشغيل بوتات تتصل بخدمات خارجية يحتاج إعداد خروج شبكي مقيد ومراجعة أمنية، ولا تغيّرها إلى شبكة مفتوحة بلا ضوابط.

## الفحوص التي أُجريت على الحزمة
- `py_compile` لملفات Python: ناجح.
- `node --check static/app.js`: ناجح.
- `pytest -q`: 24 اختبارًا ناجحًا.
- لم يتم إثبات تشغيل Docker الفعلي داخل بيئة الفحص؛ أكمل اختبار `/api/health` وتشغيل مشروع تجريبي على الخادم المستهدف.
